/*Raffy A. Wamar
 *Laurence Angelo Batu
 *Bank System
 *BSCS I-A
 */
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class BANK {
	public int numOfAcc = 0;
	//public boolean accPresent=false;

	//NECESSARY FOR HANDLING DATA
	ArrayList <Person> p = new ArrayList<Person>(); 
	ArrayList <BankAccount> ba = new ArrayList <BankAccount>();
	BankAccount bankAccount;
	Person person;
	//END
	
	//BANK COMPONENTS
	JFrame main,registration,loginwindow,bankGUI,acclist;
	JPanel actionpanel,activepanel;
	JLabel border,lbltitle,lblrtitle,lblrname,lblrsex,lblrBankID,lblrAge,lblrAddress,lblrcstatus,lblrbday,
			lblrbdtitle,lblrBID,lblrpw,lblrIDeposit,lblltitle,lblbidnote,lbllbid,lbllpw,uibankid,uibalance,
			lbluititle,lblbidtitle;
	JTextField txtrname,txtrAge,txtrpw,txtrID,txtinputamount/*,txtinputbankid,txtlbid*/;
	JPasswordField txtlpw;
	JTextArea txtrAddress,txtinquiry,txttfreport,balist;
	JRadioButton rbmale,rbfemale;
	JComboBox<String> cbcstatus,cbBMonth,cblbid,cbtbid;
	JComboBox<Integer> cbBDay,cbBYear;
	ButtonGroup bgsex;
	JScrollPane jsp;
	JButton register,login,exit,acclistexit,rback,rregister,btnlsubmit,btnlcancel,btndeposit,btnwithdraw,btninquire,
			btntransfer,btnlogout,btnadeposit,btnawithdraw,btnatransfer,btnlittle,btnedit;
	//END OF BANK COMPONENTS
	
	//BANK ACCOUNT FOR INSTANTIATION
	public class BankAccount {
		private double balance;
		private String bankID;
		private String password;
		
		public BankAccount(){
			bankID="10"+String.valueOf(((int)(Math.random()*(500-100))+100));
		}
		
		public String getBankID() {
			return this.bankID;
		}
		
		public double getBalance() {
			return this.balance;
		}
		
		public void setPassword(String temp) throws IOException {
			this.password=temp;
		}
		
		public String getPassword() {
			return this.password;
		}
		
		public void deposit(double temp) throws IOException,NumberFormatException {
			this.balance+=temp;
		}
		public void withdraw (double temp) throws IOException,NumberFormatException {
			this.balance-=temp;
		}
		
		public void transfer(BankAccount srcAcc,BankAccount dstAcc,double amount) throws IOException,NumberFormatException {
			srcAcc.withdraw(amount);
			dstAcc.deposit(amount);
		}
	}
	//END OF BANKACCOUNT
	
	//PERSON FOR INSTANTIATION
	public class Person{
		private String name,address,bmonth,cstatus;
		private int age,bday,byear;
		private String sex;
		
		public void setName(String temp) throws IOException {
			this.name=temp;
		}
		
		public String getName() {
			return name;
		}
		
		public void setAge(int temp) throws IOException {
			this.age=temp;
		}
		
		public int getAge() {
			return age;
		}
		
		public void setAddress(String temp) throws IOException {
			this.address=temp;
		}
		
		public String getAddress() {
			return address;
		}
		
		public void setSex(String temp) {
			this.sex=temp;
		}
		
		public String getSex() {
			return sex;
		}
		
		public void setBMonth(String temp) {
			this.bmonth=temp;
		}
		
		public String getBMonth() {
			return bmonth;
		}
		
		public void setBDay(int temp) {
			this.bday=temp;
		}
		
		public int getBDay() {
			return bday;
		}
		
		public void setBYear(int temp) {
			this.byear=temp;
		}
		
		public int getBYear() {
			return byear;
		}
		
		public void setCStatus(String temp) {
			this.cstatus=temp;
		}
		
		public String getCStatus() {
			return cstatus;
		}
	}
	//END OF PERSON
	
	public BANK(){
		Main();
	}
	
	//MAIN
	private void Main(){
		main = new JFrame();
		main.getContentPane().setBackground(Color.BLACK);;
		main.setSize(250, 230);
		main.setLayout(null);
		main.setLocationRelativeTo(null);
		main.setResizable(false);
		main.setUndecorated(true);
			
		//BORDER
		border = new JLabel();		
		border.setOpaque(false);
		border.setBounds(0, 0, 250, 230);
		border.setBorder(BorderFactory.createLineBorder(new Color(50,100,0), 5));
		main.add(border);
		
		//Title
		lbltitle = new JLabel("BW BANK");		
		lbltitle.setForeground(Color.YELLOW);
		lbltitle.setFont(new Font(Font.MONOSPACED, Font.BOLD, 20));
		lbltitle.setOpaque(false);
		lbltitle.setBounds(78, 10, 160, 50);
		main.add(lbltitle);
		
		//REGISTER
		register=new JButton("Register");
		register.setForeground(Color.BLUE);
		register.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		register.setOpaque(false);
		register.setContentAreaFilled(false);
		register.setBounds(55, 100, 130, 25);
		register.setBorderPainted(true);
		register.setFocusPainted(false);
		register.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				main.setVisible(false);
				Registration();
			}
		});
		main.add(register);
		
		//LOGIN
		login=new JButton("Login");
		login.setForeground(Color.BLUE);
		login.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		login.setOpaque(false);
		login.setContentAreaFilled(false);
		login.setBounds(55, 130, 130, 25);
		login.setBorderPainted(true);
		login.setFocusPainted(false);
		login.setEnabled(false);
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				main.setVisible(false);
				LoginWindow();
			}
		});
		main.add(login);
		
		//ADDITIONAL BUTTON TO SHOW BANK ACCOUNT LISTS
		btnlittle=new JButton("Acc List");
		btnlittle.setForeground(Color.BLUE);
		btnlittle.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btnlittle.setOpaque(false);
		btnlittle.setContentAreaFilled(false);
		btnlittle.setBounds(55, 160, 130, 25);
		btnlittle.setBorderPainted(true);
		btnlittle.setFocusPainted(false);
		btnlittle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				AccList();
				main.setVisible(false);
			}
		});
		main.add(btnlittle);
		
		//EXIT
		exit=new JButton("Exit");
		exit.setForeground(Color.BLUE);
		exit.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		exit.setOpaque(false);
		exit.setContentAreaFilled(false);
		exit.setBounds(55, 190, 130, 25);
		exit.setBorderPainted(true);
		exit.setFocusPainted(false);
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				System.exit(0);
			}
		});
		main.add(exit);
		main.setVisible(true);
		
	}
	//END OF MAIN
	
	//ACCOUNT LISTER
	private void AccList() {
		acclist=new JFrame();
		acclist.getContentPane().setBackground(Color.BLACK);
		acclist.setSize(300, 400);
		acclist.setLayout(null);
		acclist.setLocationRelativeTo(null);
		acclist.setResizable(false);
		acclist.setUndecorated(true);
		acclist.setVisible(true);
		
		//BORDER
		border = new JLabel();		
		border.setOpaque(false);
		border.setBounds(0, 0, 300, 400);
		border.setBorder(BorderFactory.createLineBorder(new Color(50,100,0), 5));
		acclist.add(border);
		
		//JTextArea -will display bank accounts
		balist=new JTextArea();
		balist.setLineWrap(true);
		balist.setWrapStyleWord(true);
		balist.setEditable(false);
		
		//balist.setBounds(10,10,280,330);
		
		balist.setBackground(Color.BLACK);
		balist.setForeground(Color.YELLOW);
		//self-explanatory(actual lister of account)
		for(int i=0;i<ba.size();i++) {
			balist.setText(balist.getText()+"Name: "+p.get(i).getName()+"\tBankID: "+ba.get(i).getBankID()+"\tBalance: "+ba.get(i).getBalance()+"\n");
		}
		//Scroll Function for JTextArea
		jsp=new JScrollPane(balist);
		jsp.setBounds(10,10,280,330);
		jsp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		acclist.add(jsp);
		
		//EXIT
		acclistexit=new JButton("CLOSE");
		acclistexit.setForeground(Color.BLUE);
		acclistexit.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		acclistexit.setOpaque(false);
		acclistexit.setContentAreaFilled(false);
		acclistexit.setBounds(85, 350, 130, 25);
		acclistexit.setBorderPainted(true);
		acclistexit.setFocusPainted(false);
		acclistexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				acclist.dispose();
				main.setVisible(true);
			}
		});
		acclist.add(acclistexit);
	}
	//END OF ACCOUNT LISTER
	
	//JTextField Limiter
	@SuppressWarnings("serial")
	public class JTextFieldLimit extends PlainDocument {
		private int limit;
		JTextFieldLimit(int limit) {
			super();
			this.limit = limit;
			}
		public void insertString( int offset, String  str, AttributeSet attr ) throws BadLocationException {
	    if (str == null) return;

	    if ((getLength() + str.length()) <= limit) {
	      super.insertString(offset, str, attr);
	      }
	    }
	}
	
	//REGISTRATION
	private void Registration() {
		person = new Person();
		bankAccount = new BankAccount();
		
		registration=new JFrame();
		registration.getContentPane().setBackground(Color.BLACK);;
		registration.setSize(300, 400);
		registration.setLayout(null);
		registration.setLocationRelativeTo(null);
		registration.setResizable(false);
		registration.setUndecorated(true);
		registration.setVisible(true);
		
		//BORDER
		border = new JLabel();		
		border.setOpaque(false);
		border.setBounds(0, 0, 300, 400);
		border.setBorder(BorderFactory.createLineBorder(new Color(50,100,0), 5));
		registration.add(border);
		
		//Title
		lblrtitle=new JLabel("Registration");
		lblrtitle.setForeground(Color.YELLOW);
		lblrtitle.setBounds(110,0,80,25);
		registration.add(lblrtitle);
		
		//Label Name
		lblrname= new JLabel("Name:");
		lblrname.setForeground(Color.YELLOW);
		lblrname.setBounds(20,25,40,10);
		registration.add(lblrname);
		
		//Input Name
		txtrname= new JTextField();
		txtrname.setBounds(60,25,200,20);
		registration.add(txtrname);
		
		//Label Age
		lblrAge=new JLabel("Age:");
		lblrAge.setForeground(Color.YELLOW);
		lblrAge.setBounds(20,50,40,13);
		registration.add(lblrAge);
		
		//Input Age
		txtrAge=new JTextField();
		txtrAge.setBounds(60,50,20,20);
		txtrAge.setDocument(new JTextFieldLimit(2));
		registration.add(txtrAge);
		
		//Label Sex
		lblrsex = new JLabel("Sex:");
		lblrsex.setForeground(Color.YELLOW);
		lblrsex.setBounds(90,50,40,13);
		registration.add(lblrsex);
		
		//JRadioButton Sex
		bgsex= new ButtonGroup();
		rbmale=new JRadioButton("Male");
		rbmale.setSelected(true);
		rbmale.setBounds(120,50,60,13);
		rbmale.setForeground(Color.WHITE);
		rbmale.setBackground(Color.BLACK);
		rbfemale=new JRadioButton("Female");
		rbfemale.setForeground(Color.WHITE);
		rbfemale.setBackground(Color.BLACK);
		rbfemale.setBounds(190,50,70,13);
		bgsex.add(rbmale);
		bgsex.add(rbfemale);
		registration.add(rbmale);
		registration.add(rbfemale);
		
		//Label Address
		lblrAddress = new JLabel("Address:");
		lblrAddress.setForeground(Color.YELLOW);
		lblrAddress.setBounds(20,75,55,13);
		registration.add(lblrAddress);
		
		//Input Address
		txtrAddress = new JTextArea();
		txtrAddress.setBounds(75,75,185,70);
		txtrAddress.setLineWrap(true);
		txtrAddress.setWrapStyleWord(true);
		registration.add(txtrAddress);
		
		//Label Civil Status
		lblrcstatus=new JLabel("Civil Status:");
		lblrcstatus.setForeground(Color.YELLOW);
		lblrcstatus.setBounds(20,150,70,13);
		registration.add(lblrcstatus);
		
		//JComboBox Civil Status
		cbcstatus=new JComboBox<>();
		cbcstatus.addItem("Single");
		cbcstatus.addItem("Married");
		cbcstatus.addItem("Widow");
		
		cbcstatus.setBounds(90,150,70,20);
		registration.add(cbcstatus);
		
		//Label Birthday
		lblrbday=new JLabel("Birthday:");
		lblrbday.setForeground(Color.YELLOW);
		lblrbday.setBounds(20,175,50,13);
		registration.add(lblrbday);
		
		//JComboBox BMonth
		cbBMonth=new JComboBox<>();
		cbBMonth.addItem("January");
		cbBMonth.addItem("February");
		cbBMonth.addItem("March");
		cbBMonth.addItem("April");
		cbBMonth.addItem("May");
		cbBMonth.addItem("June");
		cbBMonth.addItem("July");
		cbBMonth.addItem("August");
		cbBMonth.addItem("September");
		cbBMonth.addItem("October");
		cbBMonth.addItem("November");
		cbBMonth.addItem("December");
		
		cbBMonth.setBounds(75,175,85,20);
		registration.add(cbBMonth);
		
		//JComboBox BDay
		cbBDay=new JComboBox<>();
		for(int i=1;i<=31;i++) {
		    cbBDay.addItem(i);
		}
		
		cbBDay.setBounds(165,175,40,20);
		registration.add(cbBDay);
		
		//JComboBox BYear
		cbBYear=new JComboBox<>();
		for(int i=1990;i<=2009;i++) {
			cbBYear.addItem(i);
		}
		
		cbBYear.setBounds(210,175,55,20);
		registration.add(cbBYear);
		
		//Bank Details
		lblrbdtitle=new JLabel("Bank Details");
		lblrbdtitle.setForeground(Color.YELLOW);
		lblrbdtitle.setBounds(20,225,75,13);
		registration.add(lblrbdtitle);
		
		//Label BankID
		lblrBankID=new JLabel("BankID:");
		lblrBankID.setForeground(Color.YELLOW);
		lblrBankID.setBounds(20,250,45,13);
		lblbidnote=new JLabel("*Note: Needed to login.");
		lblbidnote.setForeground(Color.YELLOW);
		lblbidnote.setBounds(105,250,180,13);
		registration.add(lblrBankID);
		registration.add(lblbidnote);
		
		//Label Random BankID
		lblrBID=new JLabel(bankAccount.getBankID());
		lblrBID.setForeground(Color.YELLOW);
		lblrBID.setBounds(65,250,45,13);
		registration.add(lblrBID);
		
		//Label Password
		lblrpw=new JLabel("Password:");
		lblrpw.setForeground(Color.YELLOW);
		lblrpw.setBounds(20,275,65,13);
		registration.add(lblrpw);
		
		//Input Password
		txtrpw=new JTextField();
		txtrpw.setBounds(85,275,115,20);
		txtrpw.setDocument(new JTextFieldLimit(12));
		registration.add(txtrpw);
		
		//Label Initial Deposit
		lblrIDeposit=new JLabel("Initial Deposit: $");
		lblrIDeposit.setForeground(Color.YELLOW);
		lblrIDeposit.setBounds(20,305,100,13);
		registration.add(lblrIDeposit);
		
		//JTextField Initial Deposit
		txtrID=new JTextField();
		txtrID.setBounds(110,300,90,20);
		txtrID.setDocument(new JTextFieldLimit(9));
		registration.add(txtrID);
		
		//RREGISTER
		rregister=new JButton("Register");
		rregister.setForeground(Color.BLUE);
		rregister.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		rregister.setOpaque(false);
		rregister.setContentAreaFilled(false);
		rregister.setBounds(90,335,130, 25);
		rregister.setBorderPainted(true);
		rregister.setFocusPainted(false);
		rregister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String tsex;
				
				if(rbmale.isSelected()) {
					tsex = "Male";
				}else {
					tsex = "Female";
				}
				try {
					if(Double.parseDouble(txtrID.getText()) >= 5) {
						person.setName(txtrname.getText());
						person.setAge(Integer.parseInt(txtrAge.getText()));
						person.setAddress(txtrAddress.getText());
						person.setSex(tsex);
						person.setCStatus((String)cbcstatus.getSelectedItem());
						person.setBMonth((String)cbBMonth.getSelectedItem());
						person.setBDay((int)cbBDay.getSelectedItem());
						person.setBYear((int)cbBYear.getSelectedItem());
						bankAccount.deposit(Double.parseDouble(txtrID.getText()));
						bankAccount.setPassword(txtrpw.getText());
						
						p.add(numOfAcc,person);
						ba.add(numOfAcc,bankAccount);
						numOfAcc++;
						
						login.setEnabled(true);
						
						registration.dispose();
						main.setVisible(true);
					}else {
						JOptionPane.showMessageDialog(register,"Initial Deposit must atleast be $5","Invalid initial deposit",JOptionPane.ERROR_MESSAGE);
					}

				}catch(IOException e){
						JOptionPane.showMessageDialog(register,"Fill out the Form Properly","ERROR",JOptionPane.ERROR_MESSAGE);
				}catch(NumberFormatException e) {
						JOptionPane.showMessageDialog(register,"Fill out the Form Properly","ERROR",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		registration.add(rregister);
		
		//RBACK
		rback=new JButton("Back");
		rback.setForeground(Color.BLUE);
		rback.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		rback.setOpaque(false);
		rback.setContentAreaFilled(false);
		rback.setBounds(90, 365,130, 25);
		rback.setBorderPainted(true);
		rback.setFocusPainted(false);
		rback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				registration.dispose();
				main.setVisible(true);
			}
		});
		registration.add(rback);
	}
	//END OF REGISTRATION
	
	//Login Window
	private void LoginWindow() {
		loginwindow=new JFrame();
		loginwindow.getContentPane().setBackground(Color.BLACK);;
		loginwindow.setSize(250, 200);
		loginwindow.setLayout(null);
		loginwindow.setLocationRelativeTo(null);
		loginwindow.setResizable(false);
		loginwindow.setUndecorated(true);
		loginwindow.setVisible(true);
			
		//BORDER
		border = new JLabel();		
		border.setOpaque(false);
		border.setBounds(0, 0, 250, 200);
		border.setBorder(BorderFactory.createLineBorder(new Color(50,100,0), 5));
		loginwindow.add(border);
		
		//Label Login
		lblltitle = new JLabel("LOG-IN");
		lblltitle.setForeground(Color.YELLOW);
		lblltitle.setBounds(100,10,80,20);
		loginwindow.add(lblltitle);
		
		//Label lBankID
		lbllbid=new JLabel("BankID:");
		lbllbid.setForeground(Color.YELLOW);
		lbllbid.setBounds(20,50,50,20);
		loginwindow.add(lbllbid);
		
		//Label lPassword
		lbllpw=new JLabel("Password:");
		lbllpw.setForeground(Color.YELLOW);
		lbllpw.setBounds(20,75,80,20);
		loginwindow.add(lbllpw);
		
		//TextField lBankID
		/*
		txtlbid=new JTextField();
		txtlbid.setBounds(85,50,100,20);
		txtlbid.setDocument(new JTextFieldLimit(5));
		txtlbid.setText(ba.get(numOfAcc-1).getBankID());
		loginwindow.add(txtlbid);
		*/
		
		cblbid=new JComboBox<>();
		for(int i=0;i<numOfAcc;i++) {
			cblbid.addItem(ba.get(i).getBankID());
		}
		cblbid.setBounds(85,50,100,20);
		loginwindow.add(cblbid);
		
		//JPasswordField
		txtlpw=new JPasswordField();
		txtlpw.setBounds(85,75,100,20);
		txtlpw.setDocument(new JTextFieldLimit(12));
		loginwindow.add(txtlpw);
		
		//JButton Submit
		btnlsubmit=new JButton("SUBMIT");
		btnlsubmit.setBounds(65,125,120,25);
		btnlsubmit.setForeground(Color.BLUE);
		btnlsubmit.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btnlsubmit.setOpaque(false);
		btnlsubmit.setContentAreaFilled(false);
		btnlsubmit.setBorderPainted(true);
		btnlsubmit.setFocusPainted(false);
		btnlsubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				char[] pwChar = txtlpw.getPassword();
				String actualpw = "";
				for(int i = 0; i < pwChar.length; i++) {
					actualpw = actualpw + pwChar[i];
				}
				boolean nothingMatched=true;
				for(int i=0;i<ba.size();i++) {
					if(((String)cblbid.getSelectedItem()).equals(ba.get(i).getBankID()) && actualpw.equals(ba.get(i).getPassword())) {
						nothingMatched=false;
						loginwindow.dispose();
						bankUI(i);
					}
				}
				if(nothingMatched) {
					cblbid.setSelectedIndex(0);
					txtlpw.setText("");
					JOptionPane.showMessageDialog(loginwindow,"No Such Account Exists","Try Again",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		loginwindow.add(btnlsubmit);
		
		//JButton Cancel
		btnlcancel=new JButton("CANCEL");
		btnlcancel.setBounds(65,155,120,25);
		btnlcancel.setForeground(Color.BLUE);
		btnlcancel.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btnlcancel.setOpaque(false);
		btnlcancel.setContentAreaFilled(false);
		btnlcancel.setBorderPainted(true);
		btnlcancel.setFocusPainted(false);
		btnlcancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				loginwindow.dispose();
				main.setVisible(true);
			}
		});
		loginwindow.add(btnlcancel);
	}
	//END of Login Window
	
	//Edit Profile
	private void Edit(int AccEdit) {
		registration=new JFrame();
		registration.getContentPane().setBackground(Color.BLACK);;
		registration.setSize(300, 365);
		registration.setLayout(null);
		registration.setLocationRelativeTo(null);
		registration.setResizable(false);
		registration.setUndecorated(true);
		registration.setVisible(true);
		
		//BORDER
		border = new JLabel();		
		border.setOpaque(false);
		border.setBounds(0, 0, 300, 365);
		border.setBorder(BorderFactory.createLineBorder(new Color(50,100,0), 5));
		registration.add(border);
		
		//Title
		lblrtitle=new JLabel("Edit Profile");
		lblrtitle.setForeground(Color.YELLOW);
		lblrtitle.setBounds(110,0,80,25);
		registration.add(lblrtitle);
		
		//Label Name
		lblrname= new JLabel("Name:");
		lblrname.setForeground(Color.YELLOW);
		lblrname.setBounds(20,25,40,10);
		registration.add(lblrname);
		
		//Input Name
		txtrname= new JTextField();
		txtrname.setText(p.get(AccEdit).getName());
		txtrname.setBounds(60,25,200,20);
		registration.add(txtrname);
		
		//Label Age
		lblrAge=new JLabel("Age:");
		lblrAge.setForeground(Color.YELLOW);
		lblrAge.setBounds(20,50,40,13);
		registration.add(lblrAge);
		
		//Input Age
		txtrAge=new JTextField();
		txtrAge.setBounds(60,50,20,20);
		txtrAge.setDocument(new JTextFieldLimit(2));
		txtrAge.setText(String.valueOf(p.get(AccEdit).getAge()));
		registration.add(txtrAge);
		
		//Label Sex
		lblrsex = new JLabel("Sex:");
		lblrsex.setForeground(Color.YELLOW);
		lblrsex.setBounds(90,50,40,13);
		registration.add(lblrsex);
		
		//JRadioButton Sex
		bgsex= new ButtonGroup();
		rbmale=new JRadioButton("Male");
		rbmale.setSelected(true);
		rbmale.setBounds(120,50,60,13);
		rbmale.setForeground(Color.WHITE);
		rbmale.setBackground(Color.BLACK);
		rbfemale=new JRadioButton("Female");
		rbfemale.setForeground(Color.WHITE);
		rbfemale.setBackground(Color.BLACK);
		rbfemale.setBounds(190,50,70,13);
		bgsex.add(rbmale);
		bgsex.add(rbfemale);
		registration.add(rbmale);
		registration.add(rbfemale);
		
		//Label Address
		lblrAddress = new JLabel("Address:");
		lblrAddress.setForeground(Color.YELLOW);
		lblrAddress.setBounds(20,75,55,13);
		registration.add(lblrAddress);
		
		//Input Address
		txtrAddress = new JTextArea();
		txtrAddress.setText(p.get(AccEdit).getAddress());
		txtrAddress.setBounds(75,75,185,70);
		txtrAddress.setLineWrap(true);
		txtrAddress.setWrapStyleWord(true);
		registration.add(txtrAddress);
		
		//Label Civil Status
		lblrcstatus=new JLabel("Civil Status:");
		lblrcstatus.setForeground(Color.YELLOW);
		lblrcstatus.setBounds(20,150,70,13);
		registration.add(lblrcstatus);
		
		//JComboBox Civil Status
		cbcstatus=new JComboBox<>();
		cbcstatus.addItem("Single");
		cbcstatus.addItem("Married");
		cbcstatus.addItem("Widow");
		
		cbcstatus.setBounds(90,150,70,20);
		registration.add(cbcstatus);
		
		//Label Birthday
		lblrbday=new JLabel("Birthday:");
		lblrbday.setForeground(Color.YELLOW);
		lblrbday.setBounds(20,175,50,13);
		registration.add(lblrbday);
		
		//JComboBox BMonth
		cbBMonth=new JComboBox<>();
		cbBMonth.addItem("January");
		cbBMonth.addItem("February");
		cbBMonth.addItem("March");
		cbBMonth.addItem("April");
		cbBMonth.addItem("May");
		cbBMonth.addItem("June");
		cbBMonth.addItem("July");
		cbBMonth.addItem("August");
		cbBMonth.addItem("September");
		cbBMonth.addItem("October");
		cbBMonth.addItem("November");
		cbBMonth.addItem("December");
		
		cbBMonth.setBounds(75,175,85,20);
		registration.add(cbBMonth);
		
		//JComboBox BDay
		cbBDay=new JComboBox<>();
		for(int i=1;i<=31;i++) {
		    cbBDay.addItem(i);
		}
		
		cbBDay.setBounds(165,175,40,20);
		registration.add(cbBDay);
		
		//JComboBox BYear
		cbBYear=new JComboBox<>();
		for(int i=1990;i<=2009;i++) {
			cbBYear.addItem(i);
		}
		
		cbBYear.setBounds(210,175,55,20);
		registration.add(cbBYear);
		
		//Bank Details
		lblrbdtitle=new JLabel("Bank Details");
		lblrbdtitle.setForeground(Color.YELLOW);
		lblrbdtitle.setBounds(20,225,75,13);
		registration.add(lblrbdtitle);
		
		//Label BankID
		lblrBankID=new JLabel("BankID:");
		lblrBankID.setForeground(Color.YELLOW);
		lblrBankID.setBounds(20,250,45,13);
		registration.add(lblrBankID);
		
		//Label Password
		lblrpw=new JLabel("Password:");
		lblrpw.setForeground(Color.YELLOW);
		lblrpw.setBounds(20,275,65,13);
		registration.add(lblrpw);
		
		//Input Password
		txtrpw=new JTextField();
		txtrpw.setBounds(85,275,115,20);
		txtrpw.setDocument(new JTextFieldLimit(12));
		txtrpw.setText(ba.get(AccEdit).getPassword());
		registration.add(txtrpw);
		
		//Label Random BankID
		lblrBID=new JLabel(ba.get(AccEdit).getBankID());
		lblrBID.setForeground(Color.YELLOW);
		lblrBID.setBounds(65,250,45,13);
		registration.add(lblrBID);
		
		//Label of Edit
		rregister=new JButton("Edit");
		rregister.setForeground(Color.BLUE);
		rregister.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		rregister.setOpaque(false);
		rregister.setContentAreaFilled(false);
		rregister.setBounds(90,300,130, 25);
		rregister.setBorderPainted(true);
		rregister.setFocusPainted(false);
		rregister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String tsex;
				
				if(rbmale.isSelected()) {
					tsex = "Male";
				}else {
					tsex = "Female";
				}
				try {
					p.get(AccEdit).setName(txtrname.getText());
					p.get(AccEdit).setAge(Integer.parseInt(txtrAge.getText()));
					p.get(AccEdit).setAddress(txtrAddress.getText());
					p.get(AccEdit).setSex(tsex);
					p.get(AccEdit).setCStatus((String)cbcstatus.getSelectedItem());
					p.get(AccEdit).setBMonth((String)cbBMonth.getSelectedItem());
					p.get(AccEdit).setBDay((int)cbBDay.getSelectedItem());
					p.get(AccEdit).setBYear((int)cbBYear.getSelectedItem());
					ba.get(AccEdit).setPassword(txtrpw.getText());
						
						registration.dispose();
						bankUI(AccEdit);
				}catch(IOException e){
						JOptionPane.showMessageDialog(register,"Fill out the Form Properly","ERROR",JOptionPane.ERROR_MESSAGE);
				}catch(NumberFormatException e) {
						JOptionPane.showMessageDialog(register,"Fill out the Form Properly","ERROR",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		registration.add(rregister);
		
		//RBACK
		rback=new JButton("Cancel");
		rback.setForeground(Color.BLUE);
		rback.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		rback.setOpaque(false);
		rback.setContentAreaFilled(false);
		rback.setBounds(90, 330,130, 25);
		rback.setBorderPainted(true);
		rback.setFocusPainted(false);
		rback.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				registration.dispose();
				bankUI(AccEdit);
			}
		});
		registration.add(rback);
	}
	//END OF Profile Edit
	
	//BANK USER INTERFACE
	private void bankUI(int currAcc) {
		bankGUI=new JFrame();
		bankGUI.getContentPane().setBackground(Color.BLACK);
		bankGUI.setSize(300, 400);
		bankGUI.setLayout(null);
		bankGUI.setLocationRelativeTo(null);
		bankGUI.setResizable(false);
		bankGUI.setUndecorated(true);
		bankGUI.setVisible(true);
		
		//BORDER
		border = new JLabel();		
		border.setOpaque(false);
		border.setBounds(0, 0, 300, 400);
		border.setBorder(BorderFactory.createLineBorder(new Color(50,100,0), 5));
		bankGUI.add(border);
		
		//JButton Deposit
		btndeposit=new JButton("Deposit");
		btndeposit.setBounds(10,20,80,30);
		btndeposit.setBackground(Color.BLACK);
		btndeposit.setForeground(Color.BLUE);
		btndeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btnawithdraw.setVisible(false);
				btnatransfer.setVisible(false);
				txtinquiry.setVisible(false);
				
				//txtinputbankid.setVisible(false);
				cbtbid.setVisible(false);
				
				//txttfreport.setVisible(false);
				txttfreport.setText("");
				
				lblbidtitle.setVisible(false);
				lbluititle.setText("Deposit");
				txtinputamount.setVisible(true);
				btnadeposit.setVisible(true);
			}
		});
		
		//JButton Withdraw
		btnwithdraw=new JButton("Withdraw");
		btnwithdraw.setBounds(100,20,90,30);
		btnwithdraw.setBackground(Color.BLACK);
		btnwithdraw.setForeground(Color.BLUE);
		btnwithdraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btnadeposit.setVisible(false);
				btnatransfer.setVisible(false);
				txtinquiry.setVisible(false);
				
				//txtinputbankid.setVisible(false);
				cbtbid.setVisible(false);
				
				//txttfreport.setVisible(false);
				txttfreport.setText("");
				
				lblbidtitle.setVisible(false);
				lbluititle.setText("Withdraw");
				txtinputamount.setVisible(true);
				btnawithdraw.setVisible(true);
			}
		});
		
		//JButton Inquire
		btninquire=new JButton("Inquire");
		btninquire.setBounds(10,60,80,30);
		btninquire.setBackground(Color.BLACK);
		btninquire.setForeground(Color.BLUE);
		btninquire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btnawithdraw.setVisible(false);
				btnatransfer.setVisible(false);
				btnadeposit.setVisible(false);
				
				//txtinputbankid.setVisible(false);
				cbtbid.setVisible(false);
				
				//txttfreport.setVisible(false);
				txttfreport.setText("");
				
				lblbidtitle.setVisible(false);
				lbluititle.setText("");
				txtinputamount.setVisible(false);
				txtinquiry.setVisible(true);
			}
		});
		
		//JButton Transfer
		btntransfer=new JButton("Transfer");
		btntransfer.setBounds(100,60,90,30);
		btntransfer.setBackground(Color.BLACK);
		btntransfer.setForeground(Color.BLUE);
		if(numOfAcc-1==0) {
			btntransfer.setEnabled(false);
		}
		btntransfer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btnadeposit.setVisible(false);
				btnawithdraw.setVisible(false);
				txtinquiry.setVisible(false);
				lbluititle.setText("Transfer");
				lblbidtitle.setVisible(true);
				txtinputamount.setVisible(true);
				
				//txtinputbankid.setVisible(true);
				cbtbid.setVisible(true);
				
				//txttfreport.setVisible(true);
				
				txttfreport.setText("");
				btnatransfer.setVisible(true);
			}
		});
		
		//JButton Edit
		btnedit=new JButton("Edit");
		btnedit.setBounds(195,20,80,30);
		btnedit.setBackground(Color.BLACK);
		btnedit.setForeground(Color.BLUE);
		btnedit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				bankGUI.dispose();
				Edit(currAcc);
			}
		});
		
		//JButton Logout
		btnlogout=new JButton("Log Out");
		//btnlogout.setBounds(195,40,80,30);
		btnlogout.setBounds(195,60,80,30);
		btnlogout.setBackground(Color.BLACK);
		btnlogout.setForeground(Color.BLUE);
		btnlogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				bankGUI.dispose();
				main.setVisible(true);
			}
		});
		
		//JPanel for User Transaction
		actionpanel=new JPanel();
		actionpanel.setLayout(null);
		actionpanel.setBackground(Color.BLACK);
		actionpanel.add(btndeposit);
		actionpanel.add(btnwithdraw);
		actionpanel.add(btninquire);
		actionpanel.add(btntransfer);
		actionpanel.add(btnlogout);
		actionpanel.add(btnedit);
		actionpanel.setBorder(BorderFactory.createTitledBorder("SELECT TRANSACTION"));
		actionpanel.setBounds(10,300,280,95);
		bankGUI.add(actionpanel);
		
		//JLabel BankID
		uibankid=new JLabel("BankID: "+ba.get(currAcc).getBankID());
		uibankid.setForeground(Color.GREEN);
		uibankid.setBounds(10,15,90,15);
		
		//JLabel Balance
		uibalance=new JLabel("Balance: $"+ba.get(currAcc).getBalance());
		uibalance.setForeground(Color.GREEN);
		uibalance.setBounds(100,15,150,15);

		//Title
		lbluititle=new JLabel();
		lbluititle.setForeground(Color.YELLOW);
		lbluititle.setBounds(115,40,55,20);
		
		//BIDTitle
		lblbidtitle=new JLabel("Input BankID");
		lblbidtitle.setForeground(Color.YELLOW);
		lblbidtitle.setBounds(105,90,75,20);
		lblbidtitle.setVisible(false);
		
		//JTextField for Input Amount
		txtinputamount=new JTextField();
		txtinputamount.setBounds(90,60,100,20);
		txtinputamount.setVisible(false);
		
		//JTextField for Input BankID (strictly for transfer only)
		/*
		txtinputbankid=new JTextField();
		txtinputbankid.setBounds(90,110,100,20);
		txtinputbankid.setVisible(false);
		*/
		
		//JComboBox for Input BankID (for transfer v2)
		cbtbid=new JComboBox<>();
		for(int i=0;i<ba.size();i++) {
			if(ba.get(i).getBankID()!=ba.get(currAcc).getBankID()) {
				cbtbid.addItem(ba.get(i).getBankID());
			}else {
				 continue;
			}
		}
		cbtbid.setBounds(90,110,100,20);
		cbtbid.setVisible(false);
		
		//JButton actualDeposit
		btnadeposit=new JButton("DEPOSIT");
		btnadeposit.setBounds(90,100,100,40);
		btnadeposit.setBackground(Color.BLACK);
		btnadeposit.setForeground(Color.BLUE);
		btnadeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
				if(Double.parseDouble(txtinputamount.getText())<=0) {
					JOptionPane.showMessageDialog(bankGUI,"Amount must not be equal or less than 0","Invalid Amount",JOptionPane.ERROR_MESSAGE);
					txtinputamount.setText("");
				}else {
					ba.get(currAcc).deposit(Double.parseDouble(txtinputamount.getText()));
					uibalance.setText("Balance: $"+ba.get(currAcc).getBalance());
					txttfreport.setText("Transaction Successfull.");
					txtinputamount.setText("");
					}
				}catch(IOException e){
					JOptionPane.showMessageDialog(bankGUI,"Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
				}catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(bankGUI,"Must input a number.","ERROR",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnadeposit.setVisible(false);
		
		//JButton Actual Withdraw
		btnawithdraw=new JButton("WITHDRAW");
		btnawithdraw.setBounds(90,100,100,40);
		btnawithdraw.setBackground(Color.BLACK);
		btnawithdraw.setForeground(Color.BLUE);
		btnawithdraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
				if(Double.parseDouble(txtinputamount.getText())<=0) {
					JOptionPane.showMessageDialog(bankGUI,"Amount must not be equal or less than 0","Invalid Amount",JOptionPane.ERROR_MESSAGE);
					txtinputamount.setText("");
				}else if(Double.parseDouble(txtinputamount.getText())>(ba.get(currAcc).getBalance())){
					JOptionPane.showMessageDialog(bankGUI,"Amount must not be greater than the current balance","Invalid Amount",JOptionPane.ERROR_MESSAGE);
					txtinputamount.setText("");
				}else {
					ba.get(currAcc).withdraw(Double.parseDouble(txtinputamount.getText()));
					uibalance.setText("Balance: $"+ba.get(currAcc).getBalance());
					txttfreport.setText("Transaction Successfull.");
					txtinputamount.setText("");
					}
				}catch(IOException e){
					JOptionPane.showMessageDialog(bankGUI,"Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
				}catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(bankGUI,"Must input a number.","ERROR",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnawithdraw.setVisible(false);
		
		//Actual Transfer
		btnatransfer=new JButton("TRANSFER");
		btnatransfer.setBounds(90,140,100,40);
		btnatransfer.setBackground(Color.BLACK);
		btnatransfer.setForeground(Color.BLUE);
		btnatransfer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					for(int i = 0; i < ba.size(); i++) {
						if(((String)cbtbid.getSelectedItem()).equals(ba.get(i).getBankID())){
							//accPresent = true;
							
							if(Double.parseDouble(txtinputamount.getText())<=0) {
								JOptionPane.showMessageDialog(bankGUI,"Amount must not be less than or equal to zero","ERROR",JOptionPane.ERROR_MESSAGE);
								txtinputamount.setText("");
								cbtbid.setSelectedIndex(0);
							}else if(Double.parseDouble(txtinputamount.getText())>ba.get(currAcc).getBalance()) {
								JOptionPane.showMessageDialog(bankGUI,"Amount must not exceed the current balance.","ERROR",JOptionPane.ERROR_MESSAGE);
								txtinputamount.setText("");
								cbtbid.setSelectedIndex(0);
							}else {
								bankAccount.transfer(ba.get(currAcc),ba.get(i),(Double.parseDouble(txtinputamount.getText())));
								uibalance.setText("Balance: $"+ba.get(currAcc).getBalance());
								txttfreport.setText("Succesfully transferred $"+txtinputamount.getText()+" to BankID: "+ba.get(i).getBankID()+"\nBankID: "+ba.get(i).getBankID()+" Current Balance: "+ba.get(i).getBalance());
								cbtbid.setSelectedIndex(0);
								txtinputamount.setText("");
							}
						}
					}
					/*if(!accPresent) {
						JOptionPane.showMessageDialog(bankGUI, "BankID does not exist","Invalid BankID", JOptionPane.ERROR_MESSAGE);
						cbtbid.setSelectedIndex(0);
						txtinputamount.setText("");
						}*/
				}catch(IOException e) {
					JOptionPane.showMessageDialog(bankGUI,"Invalid Inputs.","ERROR",JOptionPane.ERROR_MESSAGE);
				}catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(bankGUI,"Invalid Inputs","ERROR",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnatransfer.setVisible(false);
		
		//Actual Inquiry
		txtinquiry=new JTextArea();
		txtinquiry.setLineWrap(true);
		txtinquiry.setWrapStyleWord(true);
		txtinquiry.setEditable(false);
		txtinquiry.setText("Name: "+p.get(currAcc).getName()+"\tAge: "+p.get(currAcc).getAge()+"\nSex: "+
				p.get(currAcc).getSex()+"\nAddress: "+p.get(currAcc).getAddress()+"\nBirthday: "+
				p.get(currAcc).getBMonth()+"  "+p.get(currAcc).getBDay()+"  "+p.get(currAcc).getBYear()+
				"\nCivil Status: "+p.get(currAcc).getCStatus());
		txtinquiry.setBounds(10,40,255,240);
		txtinquiry.setBackground(Color.BLACK);
		txtinquiry.setForeground(Color.YELLOW);
		txtinquiry.setVisible(false);
		
		//Transfer Report
		txttfreport=new JTextArea();
		txttfreport.setLineWrap(true);
		txttfreport.setWrapStyleWord(true);
		txttfreport.setEditable(false);
		txttfreport.setBounds(10,190,260,90);
		txttfreport.setBackground(Color.BLACK);
		txttfreport.setForeground(Color.YELLOW);
		//txttfreport.setVisible(false);
		
		//JPanel for Active Transaction
		activepanel=new JPanel();
		activepanel.setLayout(null);
		activepanel.setBackground(Color.BLACK);
		activepanel.setBorder(BorderFactory.createTitledBorder("TRANSACTION WINDOW"));
		activepanel.setBounds(10,10,280,285);
		activepanel.add(uibankid);
		activepanel.add(uibalance);
		activepanel.add(txtinquiry);
		activepanel.add(lbluititle);
		activepanel.add(txtinputamount);
		
		//activepanel.add(txtinputbankid);
		activepanel.add(cbtbid);
		
		activepanel.add(btnadeposit);
		activepanel.add(btnawithdraw);
		activepanel.add(btnatransfer);
		activepanel.add(lblbidtitle);
		activepanel.add(txttfreport);
		bankGUI.add(activepanel);
	}
	//END OF BANK UI
	
	public static void main (String args[]) {
		new BANK();
	}
}