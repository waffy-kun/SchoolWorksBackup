import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

/* Raffy A. Wa
 * Wamar, Raffy A.
 * Laurence Angelo Batu
 * Case Study - Gas Station System
 * BSCS I-A
 */

public class GasStationSystem {	
	//Variables to hold gas prices and etc.
	double unleadprc=45,dieselprc=40,premprc=50;
	double x,y,z=0;
	
	//Gas System Components
	JFrame gsui;
	JLabel border,gsname,lblunlead,lbldiesel,lblprem,lbltotal;
	JTextField gsinput,gsoutput,txtunlead,txtdiesel,txtprem;
	JTextArea gsplist;
	JRadioButton rdbtnunlead,rdbtndiesel,rdbtnprem,rdbtnliter,rdbtnamount;
	JButton btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn0,btnfill,btncncl,
			btnexit,btnbkspc,btnprice;
	ButtonGroup bgfuel,bginput;
	JPanel gsbtn,gsppanel,gspepanel;
	
	public GasStationSystem() {
		GStationUI();
	}
	
	//JTextField Limiter
	@SuppressWarnings("serial")
	public class JTextFieldLimit extends PlainDocument {
		private int limit;
		JTextFieldLimit(int limit) {
			super();
			this.limit = limit;
			}
		public void insertString( int offset, String  str, AttributeSet attr ) throws BadLocationException {
	    if (str == null) return;

	    if ((getLength() + str.length()) <= limit) {
	      super.insertString(offset, str, attr);
	      }
	    }
	}
	
	//CREATED TO HANDLE EXCEPTIONS
	public void setUnleadPrc(double temp) throws IOException,NumberFormatException {
		unleadprc=temp;
	}
	
	public void setDieselPrc(double temp) throws IOException,NumberFormatException {
		dieselprc=temp;
	}
	
	public void setPremPrc(double temp) throws IOException,NumberFormatException {
		premprc=temp;
	}
	//END
	
	private void GStationUI() {
		gsui=new JFrame();
		gsui.getContentPane().setBackground(Color.BLUE);
		gsui.setSize(600,450);
		gsui.setLayout(null);
		gsui.setLocationRelativeTo(null);
		gsui.setResizable(false);
		gsui.setUndecorated(true);
		
		//BORDER
		border = new JLabel();		
		border.setOpaque(false);
		border.setBounds(0, 0, 600, 450);
		border.setBorder(BorderFactory.createLineBorder(new Color(50,0,40), 5));
		gsui.add(border);
		
		//JPanel for Gas Products
		gsppanel=new JPanel();
		gsppanel.setLayout(null);
		gsppanel.setBackground(Color.YELLOW);
		gsppanel.setBorder(BorderFactory.createTitledBorder("Prices per Liter"));
		gsppanel.setBounds(10,10,275,225);
		gsui.add(gsppanel);
		
		//JLabel Gas Name
		gsname=new JLabel("BW GAZ");
		gsname.setBounds(100,20,50,10);
		gsppanel.add(gsname);
		
		//JTextArea for FUEL
		gsplist=new JTextArea();
		gsplist.setLineWrap(true);
		gsplist.setWrapStyleWord(true);
		gsplist.setEditable(false);
		gsplist.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		gsplist.setText("Unleaded: Php"+unleadprc+"\nDiesel: Php"+dieselprc+"\nPremium: Php"+premprc);
		gsplist.setBounds(10,40,255,80);
		gsplist.setOpaque(false);
		gsppanel.add(gsplist);
		
		//JRadioButton for Fuel Type
		bgfuel=new ButtonGroup();
		
		rdbtnunlead=new JRadioButton("Unleaded");
		rdbtnunlead.setOpaque(false);
		rdbtnunlead.setSelected(true);
		rdbtnunlead.setBounds(10,125,100,30);
		
		rdbtndiesel=new JRadioButton("Diesel");
		rdbtndiesel.setOpaque(false);
		rdbtndiesel.setBounds(10,157,100,30);
		
		rdbtnprem=new JRadioButton("Premium");
		rdbtnprem.setOpaque(false);
		rdbtnprem.setBounds(10,189,100,30);
		
		bgfuel.add(rdbtnunlead);
		bgfuel.add(rdbtndiesel);
		bgfuel.add(rdbtnprem);
		
		gsppanel.add(rdbtnunlead);
		gsppanel.add(rdbtndiesel);
		gsppanel.add(rdbtnprem);
		//END OF Fuel Selection
		
		bginput=new ButtonGroup();
		//Rdbtnliter
		rdbtnliter=new JRadioButton("Liter input");
		rdbtnliter.setOpaque(false);
		rdbtnliter.setSelected(true);
		rdbtnliter.setBounds(110,125,100,30);
		gsppanel.add(rdbtnliter);
		//End
		
		//Rdbtnamount
		rdbtnamount=new JRadioButton("Amount input");
		rdbtnamount.setOpaque(false);
		rdbtnamount.setSelected(true);
		rdbtnamount.setBounds(110,155,100,20);
		gsppanel.add(rdbtnamount);
		//End
		bginput.add(rdbtnliter);
		bginput.add(rdbtnamount);
		
		//JPanel for Price Editing
		gspepanel=new JPanel();
		gspepanel.setLayout(null);
		gspepanel.setBackground(Color.RED);
		gspepanel.setBorder(BorderFactory.createTitledBorder("Edit Prices"));
		gspepanel.setBounds(10,240,275,200);
		gsui.add(gspepanel);
		
		//JButton EditPrice
		btnprice=new JButton("Edit Price");
		btnprice.setBounds(50,110,150,20);
		btnprice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				try {
					if(Integer.parseInt(txtunlead.getText())<40||Integer.parseInt(txtdiesel.getText())<40||Integer.parseInt(txtprem.getText())<40) {
						txtunlead.setText("");
						txtdiesel.setText("");
						txtprem.setText("");
						JOptionPane.showMessageDialog(gsui,"Amount must be greater than 40","Invalid Amount",JOptionPane.ERROR_MESSAGE);
					}else {
						setUnleadPrc(Double.parseDouble(txtunlead.getText()));
						setDieselPrc(Double.parseDouble(txtdiesel.getText()));
						setPremPrc(Double.parseDouble(txtprem.getText()));
						txtunlead.setText("");
						txtdiesel.setText("");
						txtprem.setText("");
						gsplist.setText("Unleaded: Php"+unleadprc+"\nDiesel: Php"+dieselprc+"\nPremium: Php"+premprc);
					}
				}catch(IOException e) {
					JOptionPane.showMessageDialog(gsui,"Invalid Input","ERROR",JOptionPane.ERROR_MESSAGE);
				}catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(gsui,"Must input a number","ERROR",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		gspepanel.add(btnprice);
		
		//JLabel Total
		lbltotal=new JLabel("Total Earnings: Php"+z);
		lbltotal.setBounds(20,150,210,20);
		lbltotal.setForeground(Color.BLACK);
		gspepanel.add(lbltotal);
		//End of Total
		
		//JLabel lblUnlead
		lblunlead=new JLabel("Unleaded: Php");
		lblunlead.setBounds(20,20,90,20);
		lblunlead.setForeground(Color.BLACK);
		gspepanel.add(lblunlead);
		
		//JTextField txtUnlead
		txtunlead=new JTextField();
		txtunlead.setBounds(110,20,90,20);
		txtunlead.setDocument(new JTextFieldLimit(3));
		gspepanel.add(txtunlead);
		
		//JLabel lblDiesel
		lbldiesel=new JLabel("Diesel: Php");
		lbldiesel.setBounds(20,50,90,20);
		lbldiesel.setForeground(Color.BLACK);
		gspepanel.add(lbldiesel);
		
		//JTextField
		txtdiesel=new JTextField();
		txtdiesel.setBounds(110,50,90,20);
		txtdiesel.setDocument(new JTextFieldLimit(3));
		gspepanel.add(txtdiesel);
		
		//JLabel lblPremium
		lblprem=new JLabel("Premium: Php");
		lblprem.setBounds(20,80,90,20);
		lblprem.setForeground(Color.BLACK);
		gspepanel.add(lblprem);
		
		//JTextField
		txtprem=new JTextField();
		txtprem.setBounds(110,80,90,20);
		txtprem.setDocument(new JTextFieldLimit(3));
		gspepanel.add(txtprem);
		
		//JPanel for buttons
		gsbtn=new JPanel();
		gsbtn.setLayout(null);
		gsbtn.setBackground(Color.GREEN);
		gsbtn.setBorder(BorderFactory.createTitledBorder("GAS USER INTERFACE"));
		gsbtn.setBounds(290,10,300,430);
		gsui.add(gsbtn);
		
		//JTextField Input
		gsinput=new JTextField("");
		gsinput.setDocument(new JTextFieldLimit(8));
		gsinput.setEditable(false);
		gsinput.setBounds(10,20,280,40);
		gsinput.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		gsinput.setHorizontalAlignment(SwingConstants.RIGHT);
		gsbtn.add(gsinput);
		
		//JTextField Output
		gsoutput=new JTextField();
		gsoutput.setEditable(false);
		gsoutput.setBounds(10,65,280,40);
		gsoutput.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		gsoutput.setHorizontalAlignment(SwingConstants.RIGHT);
		gsbtn.add(gsoutput);
		
		//JButton zero
		btn0=new JButton("0");
		btn0.setEnabled(false);
		btn0.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn0.setBounds(30,110,70,50);
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"0");
			}
		});
		gsbtn.add(btn0);
		
		//JButton one
		btn1=new JButton("1");
		btn1.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn1.setBounds(110,110,70,50);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"1");
			}
		});
		gsbtn.add(btn1);
		
		//JButton two
		btn2=new JButton("2");
		btn2.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn2.setBounds(190,110,70,50);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"2");
			}
		});
		gsbtn.add(btn2);
		
		//JButton Three
		btn3=new JButton("3");
		btn3.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn3.setBounds(30,170,70,50);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"3");
			}
		});
		gsbtn.add(btn3);
		
		//JButton four
		btn4=new JButton("4");
		btn4.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn4.setBounds(110,170,70,50);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"4");
			}
		});
		gsbtn.add(btn4);
		
		//JButton five
		btn5=new JButton("5");
		btn5.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn5.setBounds(190,170,70,50);
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"5");
			}
		});
		gsbtn.add(btn5);
		
		//JButton Six
		btn6=new JButton("6");
		btn6.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn6.setBounds(30,230,70,50);
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"6");
			}
		});
		gsbtn.add(btn6);
		
		//JButton Seven
		btn7=new JButton("7");
		btn7.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn7.setBounds(110,230,70,50);
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"7");
			}
		});
		gsbtn.add(btn7);
		
		//JButton Eight
		btn8=new JButton("8");
		btn8.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn8.setBounds(190,230,70,50);
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"8");
			}
		});
		gsbtn.add(btn8);
		
		//JButton Nine
		btn9=new JButton("9");
		btn9.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btn9.setBounds(30,290,70,50);
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(true);
				gsoutput.setText("");
				gsinput.setText(gsinput.getText()+"9");
			}
		});
		gsbtn.add(btn9);
		
		//JButton Backspacing
		btnbkspc=new JButton("<-");
		btnbkspc.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btnbkspc.setBounds(110,290,70,50);
		btnbkspc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				String input = gsinput.getText();
				gsoutput.setText("");
				try{
				    if(!input.isEmpty()){
				        gsinput.setText(input.substring(0, input.length()-1));
				    }
				}catch(NullPointerException e){
				    gsinput.setText("");
				}
			}
		});
		gsbtn.add(btnbkspc);
		
		//JButton Cancel
		btncncl=new JButton("C");
		btncncl.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btncncl.setBounds(190,290,70,50);
		btncncl.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				btn0.setEnabled(false);
				gsoutput.setText("");
				gsinput.setText("");
			}
		});
		gsbtn.add(btncncl);
		
		//JButton Fill
		btnfill=new JButton("FILL");
		btnfill.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btnfill.setBounds(30,350,90,50);
		btnfill.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				if(rdbtnamount.isSelected()) {
				if(rdbtnunlead.isSelected()) {
					if(Double.parseDouble(gsinput.getText())>=unleadprc) {
						x=Double.parseDouble(gsinput.getText());
						y=x/unleadprc;
						gsoutput.setText(y+" Liter");
						z+=x;
						lbltotal.setText("Total Earnings: Php"+z);
					}else {
						JOptionPane.showMessageDialog(gsui,"Amount must be equal or greater than price.","Invalid amount",JOptionPane.ERROR_MESSAGE);
						gsinput.setText("");
					}
				}else if(rdbtndiesel.isSelected()) {
					if(Double.parseDouble(gsinput.getText())>=dieselprc) {
						x=Double.parseDouble(gsinput.getText());
						y=x/dieselprc;
						gsoutput.setText(y+" Liter");
						z+=x;
						lbltotal.setText("Total Earnings: Php"+z);
					}else {
						JOptionPane.showMessageDialog(gsui,"Amount must be equal or greater than price.","Invalid amount",JOptionPane.ERROR_MESSAGE);
						gsinput.setText("");
					}
				}else {
					if(Double.parseDouble(gsinput.getText())>=premprc) {
						x=Double.parseDouble(gsinput.getText());
						y=x/premprc;
						gsoutput.setText(y+" Liter");
						z+=x;
						lbltotal.setText("Total Earnings: Php"+z);
					}else {
						JOptionPane.showMessageDialog(gsui,"Amount must be equal or greater than price.","Invalid amount",JOptionPane.ERROR_MESSAGE);
						gsinput.setText("");
					}
				}
			}else {
				if(rdbtnunlead.isSelected()) {
					if(Double.parseDouble(gsinput.getText())<=0) {
						JOptionPane.showMessageDialog(gsui,"Liter must not be less than or equal to 0.","Invalid input",JOptionPane.ERROR_MESSAGE);
						gsinput.setText("");
					}else {
						x=Double.parseDouble(gsinput.getText());
						y=x*unleadprc;
						gsoutput.setText("Php "+y);
						z+=y;
						lbltotal.setText("Total Earnings: Php"+z);
					}
				}else if(rdbtndiesel.isSelected()) {
					if(Double.parseDouble(gsinput.getText())<=0) {
						JOptionPane.showMessageDialog(gsui,"Liter must not be less than or equal to 0.","Invalid input",JOptionPane.ERROR_MESSAGE);
						gsinput.setText("");
					}else {
						x=Double.parseDouble(gsinput.getText());
						y=x*dieselprc;
						gsoutput.setText("Php "+y);
						z+=y;
						lbltotal.setText("Total Earnings: Php"+z);
					}
				}else {
					if(Double.parseDouble(gsinput.getText())<=0) {
						JOptionPane.showMessageDialog(gsui,"Liter must not be less than or equal to 0.","Invalid input",JOptionPane.ERROR_MESSAGE);
						gsinput.setText("");
					}else {
						x=Double.parseDouble(gsinput.getText());
						y=x*premprc;
						gsoutput.setText("Php "+y);
						z+=y;
						lbltotal.setText("Total Earnings: Php"+z);
					}
				}
			}
			}
		});
		gsbtn.add(btnfill);
		
		//EXIT
		btnexit=new JButton("EXIT");
		btnexit.setFont(new Font(Font.MONOSPACED,Font.PLAIN,20));
		btnexit.setBounds(170,350,90,50);
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				System.exit(0);
			}
		});
		gsbtn.add(btnexit);
		gsui.setVisible(true);
	}
	
	public static void main(String args[]) {
		new GasStationSystem();
	}
}
